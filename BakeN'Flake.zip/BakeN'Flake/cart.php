<?php
session_start();
$user_id = $_SESSION["user_id"];
include('config.php')
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Bake N'Flake</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

  <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">    
  <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">    
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">
  <style type="text/css">
    
    @media screen and (max-width: 767px) {
      .pricerowadjust{
        min-width: 100px;
      }
    }

    @media screen and (min-width: 767px) {
      .rowadjust{
        min-width: 50px;
      }
    }

    @media screen and (min-width: 767px) {
      .adjustrowmargin{
        margin-left: 150px;
        margin-right: 150px;
      }
    }

    @media screen and (min-width: 767px) {
      .adjustcardrowmargin{
        margin-left: 200px;
        margin-right: 200px;
        font-size: 20px;
      }
    }

    .margintop{
      margin-top: 30px;
    }

    hr {
      margin-top: 1rem;
      margin-bottom: 1rem;
      border: 0;
      border-top: 1px solid rgba(0, 0, 0, 0.2);
    }

  </style>
</head>

<body class="bg-white">
  <!-- Start header -->
  <header class="top-navbar">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container">
        <a class="navbar-brand" href="index.php">
          <img src="" alt="" />
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbars-rs-food" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbars-rs-food">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="menu.php">Menu</a></li>
            <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
            <li class="nav-item"><a class="nav-link" href="gallery.php">Gallery</a></li>
            <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
            <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
            <li class="nav-item"><a class="nav-link" href="signup.php">Sign Up</a></li>
            <li class="nav-item active"><a class="nav-link" href="cart.php">Cart</a></li>
          </ul>
        </div>
      </div>
    </nav>
  </header>
  <!-- End header -->

  <!-- breadcrumb start-->
  <section class="breadcrumb bg-white">
      <div class="container">
          <div class="row justify-content-center">
              <div class="col-lg-12">
                  <div class="breadcrumb_iner">
                      <div class="breadcrumb_iner_item">
                          <p><a href="/">Home</a> / Cart</p>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </section>
  <!-- breadcrumb start-->

  <!--================Cart Area =================-->
  <section class="cart_area margintop">
    <div class="container">
      <div class="cart_inner">
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">Product</th>
                <th scope="col"> Product Name</th> 
                <th class="text-center" scope="col">Price</th>
                <th class="text-right" scope="col">Tool</th>
              </tr>
            </thead>
            <tbody>

              <?php
              $sqlsession = "SELECT * FROM cart WHERE user_id = $user_id";
              $resultsession = $conn->query($sqlsession);
              if ($resultsession->num_rows > 0) {
                while($rowsession = $resultsession->fetch_assoc()) {

                  $p_id = $rowsession["p_id"];

                  $sqlproduct = "SELECT * FROM product WHERE p_id = $p_id";
                  $resultproduct = $conn->query($sqlproduct);
                  if ($resultproduct->num_rows > 0) {
                    while($rowproduct = $resultproduct->fetch_assoc()) {?>
                      <tr>
                        <td>
                          <div class="media">
                            <div class="d-flex">
                                <img src="<?php echo $rowproduct['p_img']; ?>" alt="<?php echo $rowproduct['p_name']; ?>" style="height: 150px; width: auto;">
                            </div>
                          </div>
                        </td>
                        <td>
                          <div class="media-body">
                            <p><?php echo $rowproduct["p_name"]; ?></p>
                            </div>
                          </div>
                        </td>
                        <td>
                          <h5 class="text-center pricerowadjust">₹<?php echo $rowproduct["p_price"]; ?></h5>
                        </td>
                        <td>
                          <div class="text-right">
                            <form action="premove.php" method="post">
                              <input type="text" name="cartremoveproductinpute" hidden="true" value="<?php echo $p_id; ?>" style="display: none;">
                              <button type="submit" name="cartproductremovebutton" class="btn btn-danger" onclick="return confirm('sure to delete !');"><i class="fa fa-trash"></i></button>
                            </form>
                          </div>
                        </td>
                      </tr>
                      <?php
                    }
                  }
                }
              }
              ?>
            </tbody>
          </table>
        </div>
      </div>

      <?php
      $sqltextotal = "SELECT SUM(p_price) FROM cart,product WHERE cart.user_id = '$user_id' AND cart.p_id = product.p_id";
      $resulttextotal = $conn->query($sqltextotal);
      $rowtextotal = $resulttextotal->fetch_assoc();
      ?>
      <div class="card text-center adjustcardrowmargin">
        <div class="card-body">
          <b style="color: #000;">Total Amount: <?php echo "<b>₹ ".$rowtextotal["SUM(p_price)"]."</b>"; ?> + Shipping Charges</b>
        </div>
      </div>
      <br>

    </div>
  </section>

  <!--================End Cart Area =================-->

  <script src="js/jquery-3.2.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
  <script src="js/jquery.superslides.min.js"></script>
  <script src="js/images-loded.min.js"></script>
  <script src="js/isotope.min.js"></script>
  <script src="js/baguetteBox.min.js"></script>
  <script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>