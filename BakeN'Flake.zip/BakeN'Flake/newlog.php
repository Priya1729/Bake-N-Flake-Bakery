<?php
include('config.php');
session_start();

if(isset($_POST['login']))
{
	$fname=$_POST["fname"];
	$lname=$_POST["lname"];
	$mno=$_POST["mno"];
	$uname=$_POST["uname"];
	$pass=$_POST["pass"];

	$servername = "localhost";  
	$username = "root";  
	$password = "";  
	$dbname = "bakenflake";  

	$conn = new mysqli($servername, $username, $password, $dbname);  

	if ($conn->connect_error)  
	{          
    	die("Connection failed: " . $conn->connect_error); 
 	} 

	$sql = "INSERT INTO user(f_name,l_name,mobile_number,uname,pass) VALUES ('$fname','$lname','$mno','$uname','$pass')";  

	if ($conn->query($sql) === TRUE) 
	{            
    	echo "Sign up Successfully";  
	} 
	else 
	{  
    echo "Error: " . $sql . "<br>" . $conn->error;  
	} 

}
?>