<?php
include ('config.php');

$target_dir = "product_img/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
    	$p_name = $_POST["p_name"];
    	$p_price = $_POST["p_price"];
    	$category = $_POST["category"];
    	$p_img = $target_file;
    	$sql = "INSERT INTO `product`(`p_name`, `p_img`, `p_price`, `category`) VALUES ('$p_name', '$p_img', '$p_price', '$category')";
    	if ($conn->query($sql) === TRUE) {
    		echo "uploaded";
    	}
        echo "The file ".$p_img. " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
?>

<!DOCTYPE html>
<html>
<body>

<form action="upload.php" method="post" enctype="multipart/form-data">
    product name: <input type="text" name="p_name">
    <br>
    product price: <input type="number" name="p_price">
    <br>
    <label for="category">product category:</label>
    <select id="category" name="category">
    	<option value="All">All</option>
    	<option value="Cakes & Pastries">Cakes & Pastries</option>
    	<option value="Shakes">Shakes</option>
    	<option value="Coffee">Coffee</option>
    	<option value="Mousse">Mousse</option>
    	<option value="Cupcakes">Cupcakes</option>
    	<option value="Cookies">Cookies</option>
    </select>
    Select image to upload:
    <input type="file" name="fileToUpload" id="fileToUpload">

    <input type="submit" value="Upload Image" name="submit">
</form>

</body>
</html>