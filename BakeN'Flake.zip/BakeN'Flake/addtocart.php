<?php
include('config.php');
session_start();
$user_id = $_SESSION["user_id"];
$p_id = $_GET['id'];

if (isset($_SESSION['user'])) {
  $cart_sql = "INSERT INTO cart(p_id, user_id) VALUES ('$p_id','$user_id')";
  if ($conn->query($cart_sql) === TRUE) {
    echo "done";
  }?>
  <script>
    window.location.replace("index.php");
  </script>
  <?php
} else {?>
  <script>
    window.location.replace("login.php");
  </script>
  <?php
}
?>