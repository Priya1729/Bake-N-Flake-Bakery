<?php
include('config.php');
session_start();
$user_id = $_SESSION["user_id"];
$p_id = $_POST['cartremoveproductinpute'];
$sqlcartproductremove = "DELETE FROM cart WHERE user_id = '$user_id' AND p_id = '$p_id'";
if ($conn->query($sqlcartproductremove) === TRUE) {?>
	<script>
		window.history.back();
    </script>
    <?php
} else {
	echo "Error: " . $sqlcartproductremove . "<br>" . $conn->error;
	exit();
}
?>