<?php
include('config.php');
session_start();

if(isset($_POST['submit']))
{
	$name=$_POST["name"];
	$mail=$_POST["mail"];
	$no=$_POST["no"];
	$msg=$_POST["msg"];

	$sql = "INSERT INTO info(Name,Email,Mobile_No,Message) VALUES ('$name','$mail','$no','$msg')";  

	if ($conn->query($sql) === TRUE) 
	{            
    	echo "done";
    	?>

		  <script>
		    window.location.replace("contact.php");
		  </script>
		  <?php
	} 
	else 
	{  
    echo "Error: " . $sql . "<br>" . $conn->error;  
	} 

}
?>