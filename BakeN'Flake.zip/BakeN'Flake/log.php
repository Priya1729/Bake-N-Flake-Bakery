<?php
include('config.php');
session_start();

if(isset($_POST['login']))
{
	$uname=$_POST["uname"];
	$pass=$_POST["pass"];

	$sql = "SELECT * FROM user WHERE uname = '$uname' and pass = '$pass' LIMIT 1";
	$result = $conn->query($sql);
	if ($result -> num_rows > 0) {
		while($row = $result -> fetch_assoc()) {
			$_SESSION["user"] = "user";
			$_SESSION["user_id"] = $row["id"];
			?>

			<script>
			  window.location.replace("index.php");
			</script>
			<?php
		}
	}
}
?>